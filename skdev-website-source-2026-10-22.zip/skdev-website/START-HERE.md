# SKDev Website — source bundle

## Run locally

Requirements: Node.js 24.x and npm.

1. Open this folder in a terminal.
2. Run npm install.
3. Run npm run dev and open the local address shown in the terminal.

To create a production build, run npm run build.

## Put this project on Git

Create an empty repository on your Git hosting service, then from this folder run:

git init
git add .
git commit -m "Add website source"
git branch -M main
git remote add origin YOUR_REPOSITORY_URL
git push -u origin main

Replace YOUR_REPOSITORY_URL with the repository URL. This source bundle does not include Git history, installed dependencies, build output, or local environment files.
