import React, { useState } from 'react';
import { ChevronDown, MessageCircle, Mail, HelpCircle, Search, Send, X } from 'lucide-react';
import SEO from '../components/SEO';
import skdevbanner from '../assets/skdev-banner.webp';

const CATEGORIES = ['All', 'Purchasing', 'Apps & Widgets', 'Privacy', 'Support'];

const faqs = [
  /* ── Purchasing ── */
  {
    category: 'Purchasing',
    question: 'How do I purchase apps directly instead of using the Play Store?',
    answer:
      'We offer direct purchases at a discounted rate — via UPI for Indian users or PayPal for global users. Open the specific app\'s detail page on this site, scroll to the "Direct Purchase" section, and tap the Telegram link to contact us and complete your purchase.',
  },
  {
    category: 'Purchasing',
    question: 'Why is the direct purchase cheaper than the Play Store price?',
    answer:
      'Google Play charges a 15–30% platform fee on every transaction. By purchasing directly, that fee is removed entirely, so you pay less and I receive the same amount. It\'s a win-win.',
  },
  {
    category: 'Purchasing',
    question: 'What payment methods are accepted?',
    answer:
      'For Indian users: any UPI app (Google Pay, PhonePe, Paytm, BHIM, etc.). For global users: PayPal. If you need another method, reach out on Telegram and we\'ll do our best to accommodate you.',
  },
  {
    category: 'Purchasing',
    question: 'How do I get access after paying directly?',
    answer:
      'After your payment is verified, you will receive an official Google Play redeem code via Telegram. Enter this code on the Play Store to unlock the app on your Google account permanently.',
  },
  {
    category: 'Purchasing',
    question: 'Can I get a refund?',
    answer:
      'Due to the digital nature of redeem codes (which are consumed on use), direct purchases are non-refundable once the code is delivered. For Play Store purchases, Google\'s standard refund policy applies within 48 hours.',
  },

  /* ── Apps & Widgets ── */
  {
    category: 'Apps & Widgets',
    question: 'Are my widgets permanently unlocked after I purchase them?',
    answer:
      'Yes! Once purchased, the app is tied to your Google account. You can reinstall it anytime for free on any device logged into the same account. Be sure to back up your KWGT/KLWP presets to restore your setup after a reinstall.',
  },
  {
    category: 'Apps & Widgets',
    question: 'Which launcher / widget app do I need to use Aniset widgets?',
    answer:
      'Aniset widgets require KWGT (for home-screen widgets) or KLWP (for live wallpapers). Both are available on the Play Store. A free version of each app is available, but you\'ll need the Pro unlock to apply custom widget packs.',
  },
  {
    category: 'Apps & Widgets',
    question: 'The widget is not loading or showing an error. What should I do?',
    answer:
      'First, make sure you have the latest version of both Aniset and KWGT/KLWP installed. Then try: (1) long-pressing the widget → Edit → re-apply it, (2) clearing the KWGT cache in system settings, or (3) restarting your device. If the issue persists, contact us on Telegram with a screenshot.',
  },
  {
    category: 'Apps & Widgets',
    question: 'Is Anify available on the Play Store?',
    answer:
      'Yes! Anify is now officially live on Google Play. You can download it for free at https://play.google.com/store/apps/details?id=com.skdev.anify. It brings anime-themed widgets, beautiful wallpapers, Sticker Studio, and more — all in one standalone app!',
  },
  {
    category: 'Apps & Widgets',
    question: 'Which Android versions are supported by Anify?',
    answer:
      'Anify supports Android 7.0 (Nougat) all the way up to Android 16 (API 36), ensuring seamless performance, battery efficiency, and compatibility across both older and newest generation Android devices.',
  },
  {
    category: 'Apps & Widgets',
    question: 'What is Milky Launcher and when will it release?',
    answer:
      'Milky Launcher is an Android home screen launcher built natively with Jetpack Compose by Krishna Vishwakarma (@Spyou) and Satyakiran (skdevs). It features spring-based spatial motion physics tokens, adaptive circle icon masking, 4-tier instant smart search, and modular desktop widgets with 100% on-device privacy (zero internet permissions). It is scheduled to release on Google Play on 19 November 2026. You can explore the live website at https://mlweb-skdev29.vercel.app/ and follow early drops on Telegram: https://t.me/milkylc',
  },
  {
    category: 'Apps & Widgets',
    question: 'Does Gwalls require an internet connection?',
    answer:
      'Yes, Gwalls loads wallpapers from a curated online collection, so an internet connection is required to browse and download. Once a wallpaper is set, it lives locally on your device.',
  },

  /* ── Privacy ── */
  {
    category: 'Privacy',
    question: 'Do your apps collect my personal data?',
    answer:
      'No personally identifiable data is collected. Our customization apps (Aniset, Anify) process everything locally on your device. Third-party SDKs like AdMob may collect anonymized, non-identifiable usage data as described in our Privacy Policy.',
  },
  {
    category: 'Privacy',
    question: 'Are your apps ad-free?',
    answer:
      'Gwalls is completely ad-free and Aniset is a paid app with no ads. Anify is completely free to download and is supported by non-intrusive ads, which helps cover server costs and ongoing development for new widgets, wallpapers, and features.',
  },
  {
    category: 'Privacy',
    question: 'Do you sell user data to third parties?',
    answer:
      'Absolutely not. We do not sell, trade, or share any user data with third parties for marketing purposes. Any analytics collected are solely used to improve the app experience and crash diagnostics.',
  },

  /* ── Support ── */
  {
    category: 'Support',
    question: 'How can I request a new widget or feature?',
    answer:
      'The best ways to submit feature requests are: (1) join our Telegram community chat (https://t.me/skdev_chat) or follow our channel (https://t.me/skdev29), or (2) email us at satyakiran296@gmail.com. Popular requests are regularly considered for future updates.',
  },
  {
    category: 'Support',
    question: 'How do I report a bug?',
    answer:
      'Please send a bug report via Telegram (@skdev1 or in our chat https://t.me/skdev_chat) with: your device model, Android version, app version, and a description of what happened (screenshots help a lot). We aim to respond within 24–48 hours.',
  },
  {
    category: 'Support',
    question: 'I lost access to an app I purchased. Can I recover it?',
    answer:
      'If you purchased via the Play Store, simply visit the app\'s Play Store page while logged into the same Google account — it should show as purchased and allow a free reinstall. If you purchased directly via a redeem code, contact us on Telegram with your payment proof.',
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(null);
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = faqs.filter(f => {
    const matchesCategory = activeCategory === 'All' || f.category === activeCategory;
    const matchesSearch = f.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          f.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const highlightText = (text, query) => {
    if (!query || query.length < 2) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return parts.map((part, i) =>
      part.toLowerCase() === query.toLowerCase() ? (
        <span key={i} style={{ backgroundColor: 'rgba(var(--accent-rgb), 0.3)', color: 'var(--accent-primary)', borderRadius: '2px', padding: '0 2px', fontWeight: 600 }}>{part}</span>
      ) : (
        part
      )
    );
  };

  const faqJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map(f => ({
      '@type': 'Question',
      name: f.question,
      acceptedAnswer: { '@type': 'Answer', text: f.answer },
    })),
  };

  const toggle = idx => setOpenIndex(prev => (prev === idx ? null : idx));

  return (
    <div className="container animate-fade-in" style={{ paddingTop: 'clamp(1.5rem, 4vw, 3.5rem)', paddingBottom: 'clamp(1.5rem, 4vw, 3.5rem)' }}>
      <SEO
        title="Frequently Asked Questions (FAQ)"
        description="Frequently asked questions about SKDev Android apps, Anify, Aniset, direct redeem code purchases (UPI / PayPal), widget setup, and privacy."
        keywords="skdev faq, anify help, aniset kwgt setup, android widget redeem codes, upi paypal direct purchase, indie app support"
        canonical="/faq"
        image={skdevbanner}
        jsonLd={faqJsonLd}
      />

      {/* ── Hero ── */}
      <div className="editorial-intro faq-intro" style={{ textAlign: 'center', marginBottom: 'clamp(2rem, 5vw, 3rem)' }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          width: '56px', height: '56px', borderRadius: '50%',
          background: 'rgba(var(--accent-rgb), 0.1)', border: '1px solid rgba(var(--accent-rgb), 0.2)',
          color: 'var(--accent-primary)', marginBottom: '1.25rem',
        }}>
          <HelpCircle size={26} />
        </div>
        <h1 style={{ marginBottom: '0.75rem', fontSize: 'clamp(2rem, 6vw, 3.25rem)' }}>
          Frequently Asked <span className="text-gradient">Questions</span>
        </h1>
        <p style={{ fontSize: 'clamp(0.95rem, 3vw, 1.125rem)', maxWidth: '600px', margin: '0 auto clamp(1.5rem, 4vw, 2rem)', color: 'var(--text-secondary)' }}>
          Have questions? Browse by category or search through them all.
        </p>

        {/* ── Search Bar ── */}
        <div style={{ position: 'relative', maxWidth: '520px', margin: '0 auto clamp(1.25rem, 3vw, 2rem)' }}>
          <Search size={18} style={{ position: 'absolute', left: '1.15rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-secondary)' }} />
          <input
            type="text"
            aria-label="Search frequently asked questions"
            placeholder="Search questions or answers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              width: '100%',
              padding: '0.85rem 2.75rem 0.85rem 3rem',
              borderRadius: '9999px',
              border: '1px solid var(--border-color)',
              backgroundColor: 'rgba(24, 19, 29, 0.7)',
              color: 'var(--text-primary)',
              fontSize: '1rem',
              outline: 'none',
              transition: 'border-color 0.2s',
              boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.1)'
            }}
            onFocus={(e) => e.target.style.borderColor = 'var(--accent-primary)'}
            onBlur={(e) => e.target.style.borderColor = 'var(--border-color)'}
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="btn-icon"
              style={{ position: 'absolute', right: '0.5rem', top: '50%', transform: 'translateY(-50%)', padding: '0.25rem', minWidth: '32px', minHeight: '32px', color: 'var(--text-secondary)' }}
              aria-label="Clear search"
            >
              <X size={16} />
            </button>
          )}
        </div>

        {/* ── Category pills (Horizontal scrollable on mobile) ── */}
        <div className="scroll-pills-container" style={{ justifyContent: 'center', width: '100%', maxWidth: 'max-content', margin: '0 auto' }}>
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              type="button"
              aria-pressed={activeCategory === cat}
              onClick={() => { setActiveCategory(cat); setOpenIndex(null); }}
              className="scroll-pill-item"
              style={{
                padding: '0.45rem 1.15rem',
                borderRadius: '9999px',
                border: '1px solid',
                fontSize: '0.85rem',
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                whiteSpace: 'nowrap',
                borderColor:     activeCategory === cat ? 'var(--accent-primary)' : 'var(--border-color)',
                backgroundColor: activeCategory === cat ? 'var(--accent-primary)' : 'var(--bg-secondary)',
                color:           activeCategory === cat ? '#ffffff' : 'var(--text-secondary)',
                boxShadow:       activeCategory === cat ? '0 4px 14px rgba(var(--accent-rgb), 0.25)' : 'none',
              }}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* ── Accordion ── */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', maxWidth: '820px', margin: '0 auto' }}>
        {filtered.length === 0 && (
          <div className="glass-panel" style={{ textAlign: 'center', padding: '3rem 1.5rem', color: 'var(--text-secondary)' }}>
            No FAQs found matching "{searchQuery}". Try a different search term or category.
          </div>
        )}
        {filtered.map((faq, idx) => {
          const isOpen = openIndex === idx || searchQuery.length > 1;
          return (
            <div
              key={idx}
              className="glass-panel"
              style={{
                padding: 0,
                overflow: 'hidden',
                border: isOpen ? '1px solid var(--accent-primary)' : '1px solid var(--glass-border)',
                transition: 'border-color 0.25s ease, box-shadow 0.25s ease',
                boxShadow: isOpen ? '0 0 0 3px rgba(var(--accent-rgb), 0.08)' : 'none',
              }}
            >
              {/* Header */}
              <button type="button" aria-expanded={isOpen} aria-controls={`faq-answer-${idx}`} onClick={() => toggle(idx)} style={{
                width: '100%', textAlign: 'left', color: 'inherit', background: 'transparent', border: 0, cursor: 'pointer',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                gap: '0.875rem',
                padding: 'clamp(1rem, 3vw, 1.25rem) clamp(1rem, 3vw, 1.5rem)',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flex: 1, minWidth: 0 }}>
                  <span style={{
                    flexShrink: 0, width: '8px', height: '8px', borderRadius: '50%',
                    background: isOpen ? 'var(--accent-primary)' : 'var(--border-color)',
                    transition: 'background 0.25s ease',
                  }} />
                  <span style={{ fontSize: 'clamp(0.95rem, 3vw, 1.05rem)', margin: 0, fontWeight: 600, lineHeight: 1.4 }}>
                    {highlightText(faq.question, searchQuery)}
                  </span>
                </div>
                <div style={{
                  flexShrink: 0,
                  width: '28px', height: '28px',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  borderRadius: '50%',
                  background: isOpen ? 'var(--accent-primary)' : 'var(--bg-secondary)',
                  border: '1px solid var(--border-color)',
                  color: isOpen ? '#ffffff' : 'var(--text-secondary)',
                  transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)',
                  transition: 'transform 0.3s ease, background 0.25s ease, color 0.25s ease',
                }}>
                  <ChevronDown size={15} />
                </div>
              </button>

              {/* Body — CSS grid expand */}
              <div id={`faq-answer-${idx}`} role="region" aria-label={faq.question} inert={!isOpen} style={{
                display: 'grid',
                gridTemplateRows: isOpen ? '1fr' : '0fr',
                transition: 'grid-template-rows 0.3s ease',
              }}>
                <div style={{ overflow: 'hidden' }}>
                  <div style={{
                    padding: '0 clamp(1rem, 3vw, 1.5rem) clamp(1rem, 3vw, 1.5rem) clamp(1.25rem, 3vw, 2.25rem)',
                    color: 'var(--text-secondary)',
                    lineHeight: 1.7,
                    fontSize: '0.925rem',
                    borderTop: isOpen ? '1px solid rgba(255, 255, 255, 0.06)' : 'none',
                    paddingTop: isOpen ? '1rem' : '0',
                  }}>
                    {highlightText(faq.answer, searchQuery)}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Still have questions? ── */}
      <div className="glass-panel responsive-panel" style={{
        maxWidth: '820px', margin: 'clamp(2.5rem, 6vw, 4rem) auto 0',
        textAlign: 'center',
        background: 'linear-gradient(135deg, rgba(var(--accent-rgb), 0.05) 0%, rgba(var(--secondary-rgb), 0.05) 100%)',
        border: '1px solid rgba(var(--accent-rgb), 0.15)',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: 0, left: 0, right: 0, height: '3px',
          background: 'linear-gradient(90deg, transparent, var(--accent-primary), transparent)',
        }} />

        <h2 style={{ fontSize: 'clamp(1.35rem, 4vw, 1.75rem)', marginBottom: '0.5rem' }}>
          Still have questions?
        </h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.925rem', lineHeight: 1.6, maxWidth: '480px', margin: '0 auto 1.75rem auto' }}>
          Can't find what you're looking for? Reach out directly — we usually reply within 24 hours.
        </p>

        <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center', flexWrap: 'wrap' }}>
          <a
            href="https://t.me/skdev_chat"
            target="_blank"
            rel="noreferrer"
            className="btn btn-primary mobile-w-full"
            style={{ gap: '0.4rem', flex: '1 1 180px', maxWidth: '240px' }}
          >
            <MessageCircle size={16} /> Community Chat
          </a>
          <a
            href="https://t.me/skdev29"
            target="_blank"
            rel="noreferrer"
            className="btn btn-secondary mobile-w-full"
            style={{ gap: '0.4rem', flex: '1 1 180px', maxWidth: '240px' }}
          >
            <Send size={16} /> Telegram Channel
          </a>
          <a
            href="mailto:satyakiran296@gmail.com"
            className="btn btn-secondary mobile-w-full"
            style={{ gap: '0.4rem', flex: '1 1 180px', maxWidth: '240px' }}
          >
            <Mail size={16} /> Send an Email
          </a>
        </div>
      </div>
    </div>
  );
}
