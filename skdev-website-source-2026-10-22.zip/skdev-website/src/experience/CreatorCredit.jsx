import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, Send, Sparkles } from 'lucide-react';

const CREATOR_EMAIL = 'sandhiarman185@gmail.com';

export default function CreatorCredit() {
  const credit = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!('IntersectionObserver' in window)) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) return;
      setVisible(true);
      observer.disconnect();
    }, { threshold: 0.3 });
    observer.observe(credit.current);
    return () => observer.disconnect();
  }, []);

  return <div className={`creator-credit ${visible ? 'is-visible' : ''}`} ref={credit}>
    <div className="creator-credit__signature">
      <p>WEBSITE CREATED BY</p>
      <a className="creator-credit__name" href={`mailto:${CREATOR_EMAIL}`} aria-label="Arman, website creator — send an email" data-cursor="Hello">
        <span className="creator-credit__letters" aria-hidden="true">{[...'Arman'].map((letter, index) => <span className="creator-credit__letter" key={index} style={{ '--letter-index': index }}><span>{letter}</span></span>)}</span>
        <span className="creator-credit__asterisk" aria-hidden="true">✳</span>
      </a>
    </div>
    <div className="creator-credit__details">
      <span className="creator-credit__ai"><Sparkles size={15} aria-hidden="true" /> with GPT 6 Luna</span>
      <div className="creator-credit__links">
        <a className="creator-credit__email" href={`mailto:${CREATOR_EMAIL}`}>{CREATOR_EMAIL}<ArrowUpRight size={19} aria-hidden="true" /></a>
        <a className="creator-credit__telegram" href="https://t.me/Arman_0G" target="_blank" rel="noreferrer" aria-label="Message Arman on Telegram, @Arman_0G">
          <span className="creator-credit__telegram-icon"><Send size={15} aria-hidden="true" /></span>
          <span>@Arman_0G</span>
          <ArrowUpRight className="creator-credit__telegram-arrow" size={16} aria-hidden="true" />
        </a>
      </div>
      <span className="creator-credit__note">A note away from your next idea.</span>
    </div>
  </div>;
}
